export interface DharmaWord {
  title: string;
  explanation: string;
}

export type ThemeColor = 'indigo' | 'purple' | 'emerald' | 'rose' | 'blue';